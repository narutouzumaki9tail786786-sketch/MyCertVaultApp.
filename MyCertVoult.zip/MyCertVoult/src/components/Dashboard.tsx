import { useEffect, useState } from 'react';
import { supabase, Certificate, Analytics } from '../lib/supabase';
import { useTheme } from './ThemeProvider';
import { ThemeSelector } from './ThemeProvider';
import {
  Award,
  TrendingUp,
  Calendar,
  Eye,
  Upload,
  AlertCircle,
  BarChart3,
  PieChart,
} from 'lucide-react';

export function Dashboard() {
  const { theme } = useTheme();
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [analytics, setAnalytics] = useState<Analytics[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const [certsResult, analyticsResult] = await Promise.all([
        supabase
          .from('certificates')
          .select('*')
          .eq('user_id', session.user.id),
        supabase
          .from('analytics')
          .select('*')
          .eq('user_id', session.user.id)
          .order('created_at', { ascending: false })
          .limit(50),
      ]);

      setCertificates(certsResult.data || []);
      setAnalytics(analyticsResult.data || []);
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const getCardClasses = () => {
    switch (theme) {
      case 'dark':
        return 'bg-gray-800/50 backdrop-blur-xl border-gray-700';
      case 'neon':
        return 'bg-gray-900/50 backdrop-blur-xl border-purple-500/30 shadow-lg shadow-purple-500/20';
      default:
        return 'bg-white/70 backdrop-blur-xl border-gray-200';
    }
  };

  const stats = {
    total: certificates.length,
    hidden: certificates.filter((c) => c.is_hidden).length,
    expiringSoon: certificates.filter((c) => {
      if (!c.expiry_date) return false;
      const daysUntilExpiry = Math.ceil(
        (new Date(c.expiry_date).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
      );
      return daysUntilExpiry > 0 && daysUntilExpiry <= 30;
    }).length,
    byCategory: certificates.reduce((acc, cert) => {
      acc[cert.category] = (acc[cert.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>),
    recentUploads: analytics.filter((a) => a.event_type === 'upload').length,
  };

  const recentCertificates = certificates
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, 5);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
        <p className={theme === 'dark' || theme === 'neon' ? 'text-gray-400' : 'text-gray-600'}>
          Overview of your certificate portfolio
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          icon={Award}
          label="Total Certificates"
          value={stats.total}
          color="blue"
          theme={theme}
        />
        <StatCard
          icon={Upload}
          label="Recent Uploads"
          value={stats.recentUploads}
          color="green"
          theme={theme}
        />
        <StatCard
          icon={Eye}
          label="Hidden in Vault"
          value={stats.hidden}
          color="purple"
          theme={theme}
        />
        <StatCard
          icon={AlertCircle}
          label="Expiring Soon"
          value={stats.expiringSoon}
          color="red"
          theme={theme}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className={`${getCardClasses()} border rounded-2xl p-6`}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold flex items-center">
                <BarChart3 className="h-6 w-6 mr-2 text-blue-500" />
                Certificates by Category
              </h2>
            </div>

            {Object.keys(stats.byCategory).length === 0 ? (
              <p className={theme === 'dark' || theme === 'neon' ? 'text-gray-400' : 'text-gray-600'}>
                No certificates yet
              </p>
            ) : (
              <div className="space-y-4">
                {Object.entries(stats.byCategory).map(([category, count]) => (
                  <div key={category}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium capitalize">{category}</span>
                      <span className="text-sm text-gray-500">{count}</span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${(count / stats.total) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className={`${getCardClasses()} border rounded-2xl p-6`}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold flex items-center">
                <Calendar className="h-6 w-6 mr-2 text-purple-500" />
                Recent Certificates
              </h2>
            </div>

            {recentCertificates.length === 0 ? (
              <p className={theme === 'dark' || theme === 'neon' ? 'text-gray-400' : 'text-gray-600'}>
                No certificates yet
              </p>
            ) : (
              <div className="space-y-3">
                {recentCertificates.map((cert) => (
                  <div
                    key={cert.id}
                    className={`p-4 rounded-xl transition-all ${
                      theme === 'dark'
                        ? 'bg-gray-700/50 hover:bg-gray-700'
                        : theme === 'neon'
                        ? 'bg-gray-800/50 hover:bg-gray-800'
                        : 'bg-gray-50 hover:bg-gray-100'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold mb-1">{cert.title}</h3>
                        <p className="text-sm text-gray-500">{cert.issuer}</p>
                      </div>
                      <span
                        className={`text-xs px-2 py-1 rounded-full ${
                          theme === 'dark' || theme === 'neon'
                            ? 'bg-blue-900/30 text-blue-300'
                            : 'bg-blue-100 text-blue-800'
                        }`}
                      >
                        {cert.category}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      Added {new Date(cert.created_at).toLocaleDateString()}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <ThemeSelector />

          <div className={`${getCardClasses()} border rounded-2xl p-6`}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold flex items-center">
                <TrendingUp className="h-6 w-6 mr-2 text-green-500" />
                Activity
              </h2>
            </div>

            <div className="space-y-4">
              <ActivityItem
                label="Total Views"
                value={analytics.filter((a) => a.event_type === 'view').length}
                theme={theme}
              />
              <ActivityItem
                label="Searches"
                value={analytics.filter((a) => a.event_type === 'search').length}
                theme={theme}
              />
              <ActivityItem
                label="Exports"
                value={analytics.filter((a) => a.event_type === 'export').length}
                theme={theme}
              />
              <ActivityItem
                label="AI Queries"
                value={analytics.filter((a) => a.event_type === 'ai_query').length}
                theme={theme}
              />
            </div>
          </div>

          {stats.expiringSoon > 0 && (
            <div className={`${getCardClasses()} border-2 border-orange-500/50 rounded-2xl p-6`}>
              <div className="flex items-start space-x-3">
                <AlertCircle className="h-6 w-6 text-orange-500 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold mb-1">Expiring Soon</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {stats.expiringSoon} certificate{stats.expiringSoon > 1 ? 's' : ''} will expire
                    within 30 days
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  color,
  theme,
}: {
  icon: any;
  label: string;
  value: number;
  color: string;
  theme: string;
}) {
  const getCardClasses = () => {
    switch (theme) {
      case 'dark':
        return 'bg-gray-800/50 backdrop-blur-xl border-gray-700';
      case 'neon':
        return 'bg-gray-900/50 backdrop-blur-xl border-purple-500/30 shadow-lg shadow-purple-500/20';
      default:
        return 'bg-white/70 backdrop-blur-xl border-gray-200';
    }
  };

  const colorClasses: Record<string, string> = {
    blue: 'text-blue-500',
    green: 'text-green-500',
    purple: 'text-purple-500',
    red: 'text-red-500',
  };

  return (
    <div className={`${getCardClasses()} border rounded-2xl p-6 transition-all duration-200 hover:scale-105`}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className={`text-sm mb-2 ${theme === 'dark' || theme === 'neon' ? 'text-gray-400' : 'text-gray-600'}`}>
            {label}
          </p>
          <p className="text-3xl font-bold">{value}</p>
        </div>
        <div className={`p-3 rounded-xl ${theme === 'dark' ? 'bg-gray-700' : theme === 'neon' ? 'bg-gray-800' : 'bg-gray-100'}`}>
          <Icon className={`h-6 w-6 ${colorClasses[color]}`} />
        </div>
      </div>
    </div>
  );
}

function ActivityItem({
  label,
  value,
  theme,
}: {
  label: string;
  value: number;
  theme: string;
}) {
  return (
    <div className="flex items-center justify-between">
      <span className={`text-sm ${theme === 'dark' || theme === 'neon' ? 'text-gray-400' : 'text-gray-600'}`}>
        {label}
      </span>
      <span className="text-lg font-semibold">{value}</span>
    </div>
  );
}
