import { useEffect, useState } from 'react';
import { supabase, Certificate } from '../lib/supabase';
import { useTheme } from './ThemeProvider';
import {
  Upload,
  Search,
  Filter,
  Download,
  Eye,
  Trash2,
  EyeOff,
  ExternalLink,
  Calendar,
  Building,
  Tag,
  X,
  FileText,
  Image as ImageIcon,
  Loader,
  Plus,
} from 'lucide-react';

export function CertificateLibrary() {
  const { theme } = useTheme();
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [showUploadModal, setShowUploadModal] = useState(false);

  useEffect(() => {
    loadCertificates();
  }, []);

  const loadCertificates = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const { data, error } = await supabase
        .from('certificates')
        .select('*')
        .eq('user_id', session.user.id)
        .eq('is_hidden', false)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setCertificates(data || []);
    } catch (error) {
      console.error('Error loading certificates:', error);
    } finally {
      setLoading(false);
    }
  };

  const getCardClasses = () => {
    switch (theme) {
      case 'dark':
        return 'bg-gray-800/50 backdrop-blur-xl border-gray-700';
      case 'neon':
        return 'bg-gray-900/50 backdrop-blur-xl border-purple-500/30 shadow-lg shadow-purple-500/20';
      default:
        return 'bg-white/70 backdrop-blur-xl border-gray-200';
    }
  };

  const filteredCertificates = certificates.filter((cert) => {
    const matchesSearch =
      cert.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cert.issuer.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cert.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCategory = filterCategory === 'all' || cert.category === filterCategory;

    return matchesSearch && matchesCategory;
  });

  const categories = ['all', 'education', 'professional', 'skill', 'award', 'license', 'other'];

  const handleHideCertificate = async (id: string) => {
    try {
      await supabase
        .from('certificates')
        .update({ is_hidden: true })
        .eq('id', id);

      setCertificates(certificates.filter((c) => c.id !== id));
    } catch (error) {
      console.error('Error hiding certificate:', error);
    }
  };

  const handleDeleteCertificate = async (id: string, fileUrl: string) => {
    if (!confirm('Are you sure you want to delete this certificate?')) return;

    try {
      const filePath = fileUrl.split('/').slice(-2).join('/');
      await supabase.storage.from('certificates').remove([filePath]);
      await supabase.from('certificates').delete().eq('id', id);

      setCertificates(certificates.filter((c) => c.id !== id));
    } catch (error) {
      console.error('Error deleting certificate:', error);
    }
  };

  const exportCertificates = async () => {
    alert('Export feature - Download selected certificates as ZIP (requires JSZip integration)');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader className="h-8 w-8 animate-spin text-blue-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold mb-2">Certificate Library</h1>
          <p className={theme === 'dark' || theme === 'neon' ? 'text-gray-400' : 'text-gray-600'}>
            Manage and organize your certificates
          </p>
        </div>
        <button
          onClick={() => setShowUploadModal(true)}
          className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl font-semibold hover:from-blue-600 hover:to-purple-600 transition-all duration-200 shadow-lg hover:shadow-xl"
        >
          <Plus className="h-5 w-5" />
          <span>Add Certificate</span>
        </button>
      </div>

      <div className={`${getCardClasses()} border rounded-2xl p-6`}>
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search certificates, issuers, or tags..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full pl-10 pr-4 py-2.5 rounded-xl border transition-all ${
                theme === 'dark'
                  ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400'
                  : theme === 'neon'
                  ? 'bg-gray-800 border-purple-500/30 text-white placeholder-gray-400'
                  : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
              } focus:outline-none focus:ring-2 focus:ring-blue-500`}
            />
          </div>

          <div className="flex items-center gap-2">
            <Filter className="h-5 w-5 text-gray-400" />
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className={`px-4 py-2.5 rounded-xl border transition-all ${
                theme === 'dark'
                  ? 'bg-gray-700 border-gray-600 text-white'
                  : theme === 'neon'
                  ? 'bg-gray-800 border-purple-500/30 text-white'
                  : 'bg-white border-gray-300 text-gray-900'
              } focus:outline-none focus:ring-2 focus:ring-blue-500`}
            >
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat.charAt(0).toUpperCase() + cat.slice(1)}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={exportCertificates}
            className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl border transition-all ${
              theme === 'dark'
                ? 'border-gray-600 hover:bg-gray-700 text-white'
                : theme === 'neon'
                ? 'border-purple-500/30 hover:bg-purple-900/30 text-white'
                : 'border-gray-300 hover:bg-gray-50 text-gray-700'
            }`}
          >
            <Download className="h-4 w-4" />
            <span className="hidden sm:inline">Export</span>
          </button>
        </div>
      </div>

      {filteredCertificates.length === 0 ? (
        <div className={`${getCardClasses()} border rounded-2xl p-12 text-center`}>
          <FileText className="h-16 w-16 mx-auto mb-4 text-gray-400" />
          <h3 className="text-xl font-semibold mb-2">No certificates found</h3>
          <p className={theme === 'dark' || theme === 'neon' ? 'text-gray-400' : 'text-gray-600'}>
            {searchQuery || filterCategory !== 'all'
              ? 'Try adjusting your search or filters'
              : 'Start by uploading your first certificate'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCertificates.map((cert) => (
            <CertificateCard
              key={cert.id}
              certificate={cert}
              onHide={handleHideCertificate}
              onDelete={handleDeleteCertificate}
            />
          ))}
        </div>
      )}

      {showUploadModal && (
        <UploadModal
          onClose={() => setShowUploadModal(false)}
          onUploadComplete={loadCertificates}
        />
      )}
    </div>
  );
}

function CertificateCard({
  certificate,
  onHide,
  onDelete,
}: {
  certificate: Certificate;
  onHide: (id: string) => void;
  onDelete: (id: string, fileUrl: string) => void;
}) {
  const { theme } = useTheme();

  const getCardClasses = () => {
    switch (theme) {
      case 'dark':
        return 'bg-gray-800/50 backdrop-blur-xl border-gray-700 hover:border-gray-600';
      case 'neon':
        return 'bg-gray-900/50 backdrop-blur-xl border-purple-500/30 hover:border-purple-500/50 shadow-lg shadow-purple-500/10';
      default:
        return 'bg-white/70 backdrop-blur-xl border-gray-200 hover:border-gray-300';
    }
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      education: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300',
      professional: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300',
      skill: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300',
      award: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300',
      license: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300',
      other: 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300',
    };
    return colors[category] || colors.other;
  };

  return (
    <div className={`${getCardClasses()} border rounded-2xl p-6 transition-all duration-200 group`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-2">
          {certificate.file_type === 'pdf' ? (
            <FileText className="h-6 w-6 text-red-500" />
          ) : (
            <ImageIcon className="h-6 w-6 text-blue-500" />
          )}
          <span
            className={`text-xs px-2 py-1 rounded-full ${getCategoryColor(certificate.category)}`}
          >
            {certificate.category}
          </span>
        </div>

        <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={() => onHide(certificate.id)}
            className="p-1.5 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            title="Move to vault"
          >
            <EyeOff className="h-4 w-4" />
          </button>
          <button
            onClick={() => onDelete(certificate.id, certificate.file_url)}
            className="p-1.5 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30 text-red-600 transition-colors"
            title="Delete"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>

      <h3 className="font-semibold text-lg mb-2 line-clamp-2">{certificate.title}</h3>

      <div className="space-y-2 mb-4">
        <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
          <Building className="h-4 w-4 mr-2" />
          <span className="truncate">{certificate.issuer}</span>
        </div>
        <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
          <Calendar className="h-4 w-4 mr-2" />
          <span>{new Date(certificate.issue_date).toLocaleDateString()}</span>
        </div>
      </div>

      {certificate.tags.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-4">
          {certificate.tags.slice(0, 3).map((tag, idx) => (
            <span
              key={idx}
              className="text-xs px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center"
            >
              <Tag className="h-3 w-3 mr-1" />
              {tag}
            </span>
          ))}
          {certificate.tags.length > 3 && (
            <span className="text-xs px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded-full">
              +{certificate.tags.length - 3}
            </span>
          )}
        </div>
      )}

      <div className="flex space-x-2">
        <button
          onClick={() => window.open(certificate.file_url, '_blank')}
          className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-colors"
        >
          <Eye className="h-4 w-4" />
          <span>View</span>
        </button>
        {certificate.verification_url && (
          <button
            onClick={() => window.open(certificate.verification_url!, '_blank')}
            className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            title="Verify"
          >
            <ExternalLink className="h-4 w-4" />
          </button>
        )}
      </div>
    </div>
  );
}

function UploadModal({
  onClose,
  onUploadComplete,
}: {
  onClose: () => void;
  onUploadComplete: () => void;
}) {
  const { theme } = useTheme();
  const [uploading, setUploading] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    issuer: '',
    issue_date: '',
    expiry_date: '',
    category: 'professional',
    tags: '',
    credential_id: '',
    verification_url: '',
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    setUploading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('No session');

      const fileExt = file.name.split('.').pop();
      const fileName = `${session.user.id}/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('certificates')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('certificates')
        .getPublicUrl(fileName);

      await supabase.from('certificates').insert({
        user_id: session.user.id,
        title: formData.title,
        issuer: formData.issuer,
        issue_date: formData.issue_date,
        expiry_date: formData.expiry_date || null,
        category: formData.category,
        file_url: publicUrl,
        file_type: file.type.includes('pdf') ? 'pdf' : 'image',
        tags: formData.tags.split(',').map((t) => t.trim()).filter(Boolean),
        credential_id: formData.credential_id || null,
        verification_url: formData.verification_url || null,
      });

      await supabase.from('analytics').insert({
        user_id: session.user.id,
        event_type: 'upload',
        event_data: { file_type: file.type },
      });

      onUploadComplete();
      onClose();
    } catch (error) {
      console.error('Upload error:', error);
      alert('Failed to upload certificate');
    } finally {
      setUploading(false);
    }
  };

  const getModalClasses = () => {
    switch (theme) {
      case 'dark':
        return 'bg-gray-800 text-white';
      case 'neon':
        return 'bg-gray-900 text-white border-2 border-purple-500/30';
      default:
        return 'bg-white text-gray-900';
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className={`${getModalClasses()} rounded-3xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto`}>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Add Certificate</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleUpload} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Certificate File</label>
            <input
              type="file"
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={handleFileChange}
              required
              className="w-full px-4 py-2 rounded-xl border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Title</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
                className="w-full px-4 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Certificate name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Issuer</label>
              <input
                type="text"
                value={formData.issuer}
                onChange={(e) => setFormData({ ...formData, issuer: e.target.value })}
                required
                className="w-full px-4 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Issuing organization"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Issue Date</label>
              <input
                type="date"
                value={formData.issue_date}
                onChange={(e) => setFormData({ ...formData, issue_date: e.target.value })}
                required
                className="w-full px-4 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Expiry Date (Optional)</label>
              <input
                type="date"
                value={formData.expiry_date}
                onChange={(e) => setFormData({ ...formData, expiry_date: e.target.value })}
                className="w-full px-4 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Category</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-4 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="education">Education</option>
                <option value="professional">Professional</option>
                <option value="skill">Skill</option>
                <option value="award">Award</option>
                <option value="license">License</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Tags (comma-separated)</label>
              <input
                type="text"
                value={formData.tags}
                onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                className="w-full px-4 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="python, aws, certification"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Credential ID (Optional)</label>
              <input
                type="text"
                value={formData.credential_id}
                onChange={(e) => setFormData({ ...formData, credential_id: e.target.value })}
                className="w-full px-4 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="ABC123XYZ"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Verification URL (Optional)</label>
              <input
                type="url"
                value={formData.verification_url}
                onChange={(e) => setFormData({ ...formData, verification_url: e.target.value })}
                className="w-full px-4 py-2 rounded-xl border border-gray-300 dark:border-gray-600 bg-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="https://verify.example.com"
              />
            </div>
          </div>

          <div className="flex space-x-4 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 border border-gray-300 dark:border-gray-600 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={uploading}
              className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl hover:from-blue-600 hover:to-purple-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
            >
              {uploading ? (
                <>
                  <Loader className="h-5 w-5 animate-spin" />
                  <span>Uploading...</span>
                </>
              ) : (
                <span>Upload Certificate</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
