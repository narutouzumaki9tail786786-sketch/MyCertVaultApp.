import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import { Sun, Moon, Zap } from 'lucide-react';

type Theme = 'light' | 'dark' | 'neon';

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  accentColor: string;
  setAccentColor: (color: string) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>('light');
  const [accentColor, setAccentColorState] = useState('#3B82F6');

  useEffect(() => {
    const loadTheme = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        const { data } = await supabase
          .from('profiles')
          .select('theme_preference, accent_color')
          .eq('id', session.user.id)
          .maybeSingle();

        if (data) {
          setThemeState(data.theme_preference as Theme);
          setAccentColorState(data.accent_color);
        }
      }
    };

    loadTheme();
  }, []);

  const setTheme = async (newTheme: Theme) => {
    setThemeState(newTheme);
    const { data: { session } } = await supabase.auth.getSession();
    if (session) {
      await supabase
        .from('profiles')
        .update({ theme_preference: newTheme })
        .eq('id', session.user.id);
    }
  };

  const setAccentColor = async (color: string) => {
    setAccentColorState(color);
    const { data: { session } } = await supabase.auth.getSession();
    if (session) {
      await supabase
        .from('profiles')
        .update({ accent_color: color })
        .eq('id', session.user.id);
    }
  };

  return (
    <ThemeContext.Provider value={{ theme, setTheme, accentColor, setAccentColor }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
}

export function ThemeSelector() {
  const { theme, setTheme, accentColor, setAccentColor } = useTheme();

  const themes: { id: Theme; icon: typeof Sun; label: string }[] = [
    { id: 'light', icon: Sun, label: 'Light' },
    { id: 'dark', icon: Moon, label: 'Dark' },
    { id: 'neon', icon: Zap, label: 'Neon' },
  ];

  const getCardClasses = () => {
    switch (theme) {
      case 'dark':
        return 'bg-gray-800/50 backdrop-blur-xl border-gray-700';
      case 'neon':
        return 'bg-gray-900/50 backdrop-blur-xl border-purple-500/30 shadow-lg shadow-purple-500/20';
      default:
        return 'bg-white/70 backdrop-blur-xl border-gray-200';
    }
  };

  return (
    <div className={`${getCardClasses()} border rounded-2xl p-6 transition-all duration-300`}>
      <h3 className="text-lg font-semibold mb-4">Appearance</h3>

      <div className="space-y-4">
        <div>
          <label className="text-sm font-medium mb-2 block">Theme</label>
          <div className="flex gap-2">
            {themes.map((t) => (
              <button
                key={t.id}
                onClick={() => setTheme(t.id)}
                className={`flex-1 flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all duration-200 ${
                  theme === t.id
                    ? theme === 'neon'
                      ? 'border-purple-500 bg-purple-500/20'
                      : theme === 'dark'
                      ? 'border-blue-500 bg-blue-500/20'
                      : 'border-blue-500 bg-blue-50'
                    : theme === 'dark'
                    ? 'border-gray-700 hover:border-gray-600'
                    : theme === 'neon'
                    ? 'border-purple-900/30 hover:border-purple-500/50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <t.icon className="h-6 w-6 mb-2" />
                <span className="text-xs font-medium">{t.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="text-sm font-medium mb-2 block">Accent Color</label>
          <div className="flex gap-2">
            {['#3B82F6', '#8B5CF6', '#EC4899', '#10B981', '#F59E0B', '#EF4444'].map((color) => (
              <button
                key={color}
                onClick={() => setAccentColor(color)}
                className={`w-10 h-10 rounded-full transition-all duration-200 ${
                  accentColor === color ? 'ring-4 ring-offset-2 scale-110' : 'hover:scale-105'
                }`}
                style={{
                  backgroundColor: color,
                  ringColor: color,
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
