import { useEffect, useState } from 'react';
import { supabase, Certificate } from '../lib/supabase';
import { useTheme } from './ThemeProvider';
import {
  Lock,
  Eye,
  Trash2,
  FileText,
  Image as ImageIcon,
  Calendar,
  Building,
  Tag,
  EyeOff,
  Shield,
  Loader,
} from 'lucide-react';

export function HiddenVault() {
  const { theme } = useTheme();
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [loading, setLoading] = useState(true);
  const [unlocked, setUnlocked] = useState(false);

  useEffect(() => {
    if (unlocked) {
      loadHiddenCertificates();
    }
  }, [unlocked]);

  const loadHiddenCertificates = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const { data, error } = await supabase
        .from('certificates')
        .select('*')
        .eq('user_id', session.user.id)
        .eq('is_hidden', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setCertificates(data || []);
    } catch (error) {
      console.error('Error loading hidden certificates:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUnlock = () => {
    setUnlocked(true);
  };

  const handleUnhide = async (id: string) => {
    try {
      await supabase
        .from('certificates')
        .update({ is_hidden: false })
        .eq('id', id);

      setCertificates(certificates.filter((c) => c.id !== id));
    } catch (error) {
      console.error('Error unhiding certificate:', error);
    }
  };

  const handleDelete = async (id: string, fileUrl: string) => {
    if (!confirm('Are you sure you want to permanently delete this certificate?')) return;

    try {
      const filePath = fileUrl.split('/').slice(-2).join('/');
      await supabase.storage.from('certificates').remove([filePath]);
      await supabase.from('certificates').delete().eq('id', id);

      setCertificates(certificates.filter((c) => c.id !== id));
    } catch (error) {
      console.error('Error deleting certificate:', error);
    }
  };

  const getCardClasses = () => {
    switch (theme) {
      case 'dark':
        return 'bg-gray-800/50 backdrop-blur-xl border-gray-700';
      case 'neon':
        return 'bg-gray-900/50 backdrop-blur-xl border-purple-500/30 shadow-lg shadow-purple-500/20';
      default:
        return 'bg-white/70 backdrop-blur-xl border-gray-200';
    }
  };

  if (!unlocked) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className={`${getCardClasses()} border rounded-3xl p-12 max-w-md w-full text-center`}>
          <div className="relative inline-block mb-6">
            <Shield className="h-24 w-24 text-purple-500" />
            {theme === 'neon' && (
              <div className="absolute inset-0 animate-pulse">
                <Shield className="h-24 w-24 text-purple-400 opacity-50" />
              </div>
            )}
          </div>

          <h2 className="text-2xl font-bold mb-4">Hidden Vault</h2>
          <p className={`mb-8 ${theme === 'dark' || theme === 'neon' ? 'text-gray-400' : 'text-gray-600'}`}>
            Your private certificate storage. Unlock to access hidden certificates.
          </p>

          <button
            onClick={handleUnlock}
            className="w-full px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl font-semibold hover:from-purple-600 hover:to-pink-600 transition-all duration-200 flex items-center justify-center space-x-2 shadow-lg hover:shadow-xl"
          >
            <Lock className="h-5 w-5" />
            <span>Unlock Vault</span>
          </button>

          <p className="text-xs text-gray-500 mt-4">
            In production, this would require biometric authentication or PIN
          </p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader className="h-8 w-8 animate-spin text-purple-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2 flex items-center">
            <Shield className="h-8 w-8 mr-3 text-purple-500" />
            Hidden Vault
          </h1>
          <p className={theme === 'dark' || theme === 'neon' ? 'text-gray-400' : 'text-gray-600'}>
            Private certificate storage
          </p>
        </div>

        <button
          onClick={() => setUnlocked(false)}
          className={`flex items-center space-x-2 px-4 py-2 rounded-xl border transition-all ${
            theme === 'dark'
              ? 'border-gray-600 hover:bg-gray-700 text-white'
              : theme === 'neon'
              ? 'border-purple-500/30 hover:bg-purple-900/30 text-white'
              : 'border-gray-300 hover:bg-gray-50 text-gray-700'
          }`}
        >
          <Lock className="h-4 w-4" />
          <span>Lock Vault</span>
        </button>
      </div>

      {certificates.length === 0 ? (
        <div className={`${getCardClasses()} border rounded-2xl p-12 text-center`}>
          <EyeOff className="h-16 w-16 mx-auto mb-4 text-gray-400" />
          <h3 className="text-xl font-semibold mb-2">No hidden certificates</h3>
          <p className={theme === 'dark' || theme === 'neon' ? 'text-gray-400' : 'text-gray-600'}>
            Hide sensitive certificates from your main library by moving them to the vault
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {certificates.map((cert) => (
            <VaultCertificateCard
              key={cert.id}
              certificate={cert}
              onUnhide={handleUnhide}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function VaultCertificateCard({
  certificate,
  onUnhide,
  onDelete,
}: {
  certificate: Certificate;
  onUnhide: (id: string) => void;
  onDelete: (id: string, fileUrl: string) => void;
}) {
  const { theme } = useTheme();

  const getCardClasses = () => {
    switch (theme) {
      case 'dark':
        return 'bg-gray-800/50 backdrop-blur-xl border-gray-700 hover:border-purple-500/50';
      case 'neon':
        return 'bg-gray-900/50 backdrop-blur-xl border-purple-500/30 hover:border-purple-500 shadow-lg shadow-purple-500/10';
      default:
        return 'bg-white/70 backdrop-blur-xl border-gray-200 hover:border-purple-300';
    }
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      education: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300',
      professional: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300',
      skill: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300',
      award: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300',
      license: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300',
      other: 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300',
    };
    return colors[category] || colors.other;
  };

  return (
    <div
      className={`${getCardClasses()} border-2 rounded-2xl p-6 transition-all duration-200 group relative overflow-hidden`}
    >
      <div className="absolute top-0 right-0 w-20 h-20 bg-purple-500/10 rounded-bl-full" />

      <div className="flex items-start justify-between mb-4 relative">
        <div className="flex items-center space-x-2">
          {certificate.file_type === 'pdf' ? (
            <FileText className="h-6 w-6 text-red-500" />
          ) : (
            <ImageIcon className="h-6 w-6 text-blue-500" />
          )}
          <span
            className={`text-xs px-2 py-1 rounded-full ${getCategoryColor(certificate.category)}`}
          >
            {certificate.category}
          </span>
        </div>

        <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={() => onUnhide(certificate.id)}
            className="p-1.5 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            title="Unhide"
          >
            <Eye className="h-4 w-4" />
          </button>
          <button
            onClick={() => onDelete(certificate.id, certificate.file_url)}
            className="p-1.5 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30 text-red-600 transition-colors"
            title="Delete"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>

      <h3 className="font-semibold text-lg mb-2 line-clamp-2">{certificate.title}</h3>

      <div className="space-y-2 mb-4">
        <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
          <Building className="h-4 w-4 mr-2" />
          <span className="truncate">{certificate.issuer}</span>
        </div>
        <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
          <Calendar className="h-4 w-4 mr-2" />
          <span>{new Date(certificate.issue_date).toLocaleDateString()}</span>
        </div>
      </div>

      {certificate.tags.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-4">
          {certificate.tags.slice(0, 3).map((tag, idx) => (
            <span
              key={idx}
              className="text-xs px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center"
            >
              <Tag className="h-3 w-3 mr-1" />
              {tag}
            </span>
          ))}
          {certificate.tags.length > 3 && (
            <span className="text-xs px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded-full">
              +{certificate.tags.length - 3}
            </span>
          )}
        </div>
      )}

      <button
        onClick={() => window.open(certificate.file_url, '_blank')}
        className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl hover:from-purple-600 hover:to-pink-600 transition-all"
      >
        <Eye className="h-4 w-4" />
        <span>View</span>
      </button>
    </div>
  );
}
