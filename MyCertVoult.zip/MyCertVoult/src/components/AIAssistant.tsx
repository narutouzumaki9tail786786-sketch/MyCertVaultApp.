import { useState, useRef, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useTheme } from './ThemeProvider';
import { Send, Bot, User, Sparkles, Loader, MessageCircle } from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export function AIAssistant() {
  const { theme } = useTheme();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content:
        "Hello! I'm Aero, your AI certificate assistant. I can help you search your certificates using natural language, provide insights about your portfolio, and answer questions. Try asking me something like 'Show me all my AWS certifications' or 'What certificates expire soon?'",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const { data: certificates } = await supabase
        .from('certificates')
        .select('*')
        .eq('user_id', session.user.id);

      const response = await generateAIResponse(input, certificates || []);

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);

      await supabase.from('ai_interactions').insert({
        user_id: session.user.id,
        query: input,
        response: response,
        context: { certificate_count: certificates?.length || 0 },
      });

      await supabase.from('analytics').insert({
        user_id: session.user.id,
        event_type: 'ai_query',
        event_data: { query_length: input.length },
      });
    } catch (error) {
      console.error('Error:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Sorry, I encountered an error. Please try again.',
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const generateAIResponse = async (query: string, certificates: any[]): Promise<string> => {
    const lowerQuery = query.toLowerCase();

    if (lowerQuery.includes('how many') || lowerQuery.includes('count')) {
      return `You have a total of ${certificates.length} certificates in your collection.`;
    }

    if (lowerQuery.includes('expire') || lowerQuery.includes('expiring')) {
      const expiringSoon = certificates.filter((cert) => {
        if (!cert.expiry_date) return false;
        const daysUntilExpiry = Math.ceil(
          (new Date(cert.expiry_date).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
        );
        return daysUntilExpiry > 0 && daysUntilExpiry <= 90;
      });

      if (expiringSoon.length === 0) {
        return 'Great news! None of your certificates are expiring in the next 90 days.';
      }

      const list = expiringSoon
        .map(
          (cert) =>
            `- **${cert.title}** from ${cert.issuer} (expires ${new Date(cert.expiry_date).toLocaleDateString()})`
        )
        .join('\n');

      return `You have ${expiringSoon.length} certificate(s) expiring in the next 90 days:\n\n${list}`;
    }

    if (lowerQuery.includes('category') || lowerQuery.includes('categories')) {
      const categories = certificates.reduce((acc, cert) => {
        acc[cert.category] = (acc[cert.category] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const list = Object.entries(categories)
        .map(([cat, count]) => `- **${cat}**: ${count} certificate(s)`)
        .join('\n');

      return `Here's your certificate breakdown by category:\n\n${list}`;
    }

    if (lowerQuery.includes('recent') || lowerQuery.includes('latest')) {
      const recent = certificates
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
        .slice(0, 5);

      if (recent.length === 0) {
        return "You haven't uploaded any certificates yet.";
      }

      const list = recent
        .map((cert) => `- **${cert.title}** from ${cert.issuer}`)
        .join('\n');

      return `Here are your most recent certificates:\n\n${list}`;
    }

    const matchingCerts = certificates.filter(
      (cert) =>
        cert.title.toLowerCase().includes(lowerQuery) ||
        cert.issuer.toLowerCase().includes(lowerQuery) ||
        cert.tags.some((tag: string) => tag.toLowerCase().includes(lowerQuery))
    );

    if (matchingCerts.length > 0) {
      const list = matchingCerts
        .slice(0, 5)
        .map((cert) => `- **${cert.title}** from ${cert.issuer} (${cert.category})`)
        .join('\n');

      return `I found ${matchingCerts.length} certificate(s) matching your search:\n\n${list}${
        matchingCerts.length > 5 ? '\n\n...and more!' : ''
      }`;
    }

    return `I understand you're asking about "${query}". I can help you with:\n\n- Searching certificates by name, issuer, or tags\n- Finding certificates expiring soon\n- Getting statistics about your certificate portfolio\n- Viewing recent certificates\n- Breaking down certificates by category\n\nTry rephrasing your question or asking about one of these topics!`;
  };

  const getCardClasses = () => {
    switch (theme) {
      case 'dark':
        return 'bg-gray-800/50 backdrop-blur-xl border-gray-700';
      case 'neon':
        return 'bg-gray-900/50 backdrop-blur-xl border-purple-500/30 shadow-lg shadow-purple-500/20';
      default:
        return 'bg-white/70 backdrop-blur-xl border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2 flex items-center">
          <Sparkles className="h-8 w-8 mr-3 text-purple-500" />
          AI Assistant
        </h1>
        <p className={theme === 'dark' || theme === 'neon' ? 'text-gray-400' : 'text-gray-600'}>
          Ask questions about your certificates in natural language
        </p>
      </div>

      <div className={`${getCardClasses()} border rounded-2xl overflow-hidden`}>
        <div className="h-[600px] flex flex-col">
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`flex items-start space-x-3 max-w-[80%] ${
                    message.role === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                  }`}
                >
                  <div
                    className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
                      message.role === 'user'
                        ? 'bg-blue-500 text-white'
                        : theme === 'neon'
                        ? 'bg-purple-600 text-white'
                        : theme === 'dark'
                        ? 'bg-gray-700 text-white'
                        : 'bg-gray-200 text-gray-700'
                    }`}
                  >
                    {message.role === 'user' ? (
                      <User className="h-5 w-5" />
                    ) : (
                      <Bot className="h-5 w-5" />
                    )}
                  </div>

                  <div
                    className={`rounded-2xl px-4 py-3 ${
                      message.role === 'user'
                        ? 'bg-blue-500 text-white'
                        : theme === 'dark'
                        ? 'bg-gray-700 text-white'
                        : theme === 'neon'
                        ? 'bg-gray-800 text-white'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    <div className="prose prose-sm max-w-none">
                      {message.content.split('\n').map((line, idx) => {
                        if (line.startsWith('- **')) {
                          const boldMatch = line.match(/\*\*(.*?)\*\*/);
                          if (boldMatch) {
                            const parts = line.split(/\*\*(.*?)\*\*/);
                            return (
                              <div key={idx} className="ml-4 mb-1">
                                • <strong>{boldMatch[1]}</strong>
                                {parts[2]}
                              </div>
                            );
                          }
                        }
                        return line ? (
                          <p key={idx} className="mb-1">
                            {line}
                          </p>
                        ) : (
                          <br key={idx} />
                        );
                      })}
                    </div>
                    <p className="text-xs opacity-60 mt-2">
                      {message.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              </div>
            ))}

            {loading && (
              <div className="flex justify-start">
                <div className="flex items-start space-x-3">
                  <div
                    className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
                      theme === 'neon'
                        ? 'bg-purple-600 text-white'
                        : theme === 'dark'
                        ? 'bg-gray-700 text-white'
                        : 'bg-gray-200 text-gray-700'
                    }`}
                  >
                    <Bot className="h-5 w-5" />
                  </div>
                  <div
                    className={`rounded-2xl px-4 py-3 ${
                      theme === 'dark'
                        ? 'bg-gray-700'
                        : theme === 'neon'
                        ? 'bg-gray-800'
                        : 'bg-gray-100'
                    }`}
                  >
                    <Loader className="h-5 w-5 animate-spin" />
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          <div className={`border-t p-4 ${theme === 'dark' ? 'border-gray-700' : theme === 'neon' ? 'border-purple-500/30' : 'border-gray-200'}`}>
            <div className="flex space-x-3">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask me anything about your certificates..."
                disabled={loading}
                className={`flex-1 px-4 py-3 rounded-xl border transition-all ${
                  theme === 'dark'
                    ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400'
                    : theme === 'neon'
                    ? 'bg-gray-800 border-purple-500/30 text-white placeholder-gray-400'
                    : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
                } focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50`}
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || loading}
                className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl hover:from-blue-600 hover:to-purple-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
              >
                <Send className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              {[
                'How many certificates do I have?',
                'Show certificates expiring soon',
                'Break down by category',
                'Show recent certificates',
              ].map((suggestion, idx) => (
                <button
                  key={idx}
                  onClick={() => setInput(suggestion)}
                  disabled={loading}
                  className={`text-xs px-3 py-1.5 rounded-full transition-all ${
                    theme === 'dark'
                      ? 'bg-gray-700 hover:bg-gray-600 text-gray-300'
                      : theme === 'neon'
                      ? 'bg-gray-800 hover:bg-gray-700 text-purple-300'
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                  } disabled:opacity-50`}
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className={`${getCardClasses()} border rounded-2xl p-6`}>
        <h3 className="font-semibold mb-3 flex items-center">
          <MessageCircle className="h-5 w-5 mr-2 text-blue-500" />
          What can I help you with?
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <h4 className="font-medium mb-2">Search & Discovery</h4>
            <ul className={`space-y-1 ${theme === 'dark' || theme === 'neon' ? 'text-gray-400' : 'text-gray-600'}`}>
              <li>• Find certificates by name or issuer</li>
              <li>• Search by tags or keywords</li>
              <li>• Filter by category</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium mb-2">Analytics & Insights</h4>
            <ul className={`space-y-1 ${theme === 'dark' || theme === 'neon' ? 'text-gray-400' : 'text-gray-600'}`}>
              <li>• Certificate expiration tracking</li>
              <li>• Portfolio statistics</li>
              <li>• Category breakdown</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
