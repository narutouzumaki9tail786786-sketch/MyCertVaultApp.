import { useEffect, useState } from 'react';
import { supabase } from './lib/supabase';
import { Auth } from './components/Auth';
import { Dashboard } from './components/Dashboard';
import { CertificateLibrary } from './components/CertificateLibrary';
import { HiddenVault } from './components/HiddenVault';
import { AIAssistant } from './components/AIAssistant';
import { ThemeProvider, useTheme } from './components/ThemeProvider';
import { Layout, Home, Award, Lock, MessageCircle, LogOut } from 'lucide-react';

type View = 'dashboard' | 'certificates' | 'vault' | 'assistant';

function AppContent() {
  const [session, setSession] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const { theme } = useTheme();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  if (!session) {
    return <Auth />;
  }

  const getThemeClasses = () => {
    switch (theme) {
      case 'dark':
        return 'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white';
      case 'neon':
        return 'bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white';
      default:
        return 'bg-gradient-to-br from-blue-50 via-white to-purple-50 text-gray-900';
    }
  };

  const getCardClasses = () => {
    switch (theme) {
      case 'dark':
        return 'bg-gray-800/50 backdrop-blur-xl border-gray-700';
      case 'neon':
        return 'bg-gray-900/50 backdrop-blur-xl border-purple-500/30 shadow-lg shadow-purple-500/20';
      default:
        return 'bg-white/70 backdrop-blur-xl border-gray-200';
    }
  };

  const navItems = [
    { id: 'dashboard' as View, icon: Home, label: 'Dashboard' },
    { id: 'certificates' as View, icon: Award, label: 'Certificates' },
    { id: 'vault' as View, icon: Lock, label: 'Vault' },
    { id: 'assistant' as View, icon: MessageCircle, label: 'AI Assistant' },
  ];

  return (
    <div className={`min-h-screen ${getThemeClasses()} transition-colors duration-300`}>
      <nav className={`${getCardClasses()} border-b sticky top-0 z-50 transition-all duration-300`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Layout className="h-8 w-8 text-blue-500" />
                {theme === 'neon' && (
                  <div className="absolute inset-0 animate-pulse">
                    <Layout className="h-8 w-8 text-purple-400 opacity-50" />
                  </div>
                )}
              </div>
              <span className="text-xl font-bold">CertVault</span>
            </div>

            <div className="hidden md:flex items-center space-x-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setCurrentView(item.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                    currentView === item.id
                      ? theme === 'neon'
                        ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/50'
                        : theme === 'dark'
                        ? 'bg-gray-700 text-white'
                        : 'bg-blue-500 text-white'
                      : theme === 'dark'
                      ? 'text-gray-300 hover:bg-gray-700'
                      : theme === 'neon'
                      ? 'text-purple-200 hover:bg-purple-900/30'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <item.icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </button>
              ))}
            </div>

            <button
              onClick={handleSignOut}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                theme === 'dark'
                  ? 'text-gray-300 hover:bg-gray-700'
                  : theme === 'neon'
                  ? 'text-purple-200 hover:bg-purple-900/30'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <LogOut className="h-5 w-5" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>

          <div className="md:hidden flex items-center space-x-2 pb-3 overflow-x-auto">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id)}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg whitespace-nowrap transition-all duration-200 ${
                  currentView === item.id
                    ? theme === 'neon'
                      ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/50'
                      : theme === 'dark'
                      ? 'bg-gray-700 text-white'
                      : 'bg-blue-500 text-white'
                    : theme === 'dark'
                    ? 'text-gray-300 hover:bg-gray-700'
                    : theme === 'neon'
                    ? 'text-purple-200 hover:bg-purple-900/30'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <item.icon className="h-4 w-4" />
                <span className="text-sm">{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentView === 'dashboard' && <Dashboard />}
        {currentView === 'certificates' && <CertificateLibrary />}
        {currentView === 'vault' && <HiddenVault />}
        {currentView === 'assistant' && <AIAssistant />}
      </main>
    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}

export default App;
