import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Certificate = {
  id: string;
  user_id: string;
  title: string;
  issuer: string;
  issue_date: string;
  expiry_date: string | null;
  category: 'education' | 'professional' | 'skill' | 'award' | 'license' | 'other';
  file_url: string;
  file_type: string;
  thumbnail_url: string | null;
  is_hidden: boolean;
  tags: string[];
  credential_id: string | null;
  verification_url: string | null;
  metadata: Record<string, any>;
  created_at: string;
  updated_at: string;
};

export type Profile = {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  theme_preference: 'light' | 'dark' | 'neon';
  accent_color: string;
  created_at: string;
  updated_at: string;
};

export type AIInteraction = {
  id: string;
  user_id: string;
  query: string;
  response: string;
  context: Record<string, any>;
  created_at: string;
};

export type Analytics = {
  id: string;
  user_id: string;
  event_type: string;
  event_data: Record<string, any>;
  created_at: string;
};
